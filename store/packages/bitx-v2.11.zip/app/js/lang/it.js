window.it = {

  "searchTodo":"Cercando ToDo...",

  "header_overdues": "Tardato",
  "header_today": "Oggi",
  "header_upcoming": "Prossimo",
  "header_noduedate": "Nessuna scadenza",

  "createdDate": "Creato:", //

  "dayLate": "giorno in ritardo",
  "daysLate": "giorni in ritardo",

  "dayLeft": "giorno rimasto", //"Manca un giorno",
  "daysLeft": "giorni rimasti",

  "lastUpdate": "Ultimi aggiornamenti:",
  "minutesAgo":"minuti fa",
  "hoursAgo":"ore fa",
  "daysAgo":"giorni fa",

  "visitTodo": "Visita questo todo",
  "assignedTo": "Assegnato a {x}",

  "countOverdues":"ToDo(s) in ritardo",
  "countToday":"ToDo(s) per oggi",
  "countUpcoming":"ToDo(s) a venire",
  "countNoDueDate":"ToDo(s) nessuna scadenza",

  "needAuth1":"Cliccate su",
  "needAuth2":"per sincronizzare vostro account Basecamp con l'estensione.",

  "thankYou":"Grazie!",
  "syncMess":"La vostra estensione ToDo-Basecamp è collegata con vostro account! Siete pronti per iniziare l'uso di vostra estensione.",

  "achievement1":"Ben fatto !",
  "achievement2":"Buon lavoro !",
  "achievement3":"Eccellente!"

};