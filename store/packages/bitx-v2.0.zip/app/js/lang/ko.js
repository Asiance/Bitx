window.ko = {

  "searchTodo":"일정을  검색하세요.",

  "header_overdues": "기한 지난 일정",
  "header_today": "오늘의 일정",
  "header_upcoming": "다가오는 일정",
  "header_noduedate": "기한 없는 일정",

  "createdDate": "추가 됨:", // Not match perfectly

  "dayLate": "일 늦음",
  "daysLate": "일 늦음",

  "dayLeft": "일 남음",
  "daysLeft": "일 남음",

  "lastUpdate": "마지막 업데이트",
  "minutesAgo":"분 전",
  "hoursAgo":"시간 전",
  "daysAgo":"일 전",

  "visitTodo": "Visit this todo",
  "assignedTo": "{x}에 할당",

  "countOverdues": "개의 기한 지난 일정",
  "countToday": "개의 일정",
  "countUpcoming": "개의 다가오는 일정",
  "countNoDueDate": "개의 기한 없는 일정",

  "needAuth1": "Basecamp계정과 extension을 동기화하려면,",
  "needAuth2": "를 클릭하세요.",

  "thankYou": "감사합니다!",
  "syncMess": "당신의 계정이 Todo Basecamp Extension에 성공적으로 연결되었습니다. 이제 Extension을 사용할 수 있습니다.",

  "achievement1":"수고하셨습니다!",
  "achievement2":"참 잘했어요!",
  "achievement3":"대단합니다!"

};