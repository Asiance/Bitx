window.pt = {

  "searchTodo":"Procurando ToDo....",

  "header_overdues": "Atrasos",
  "header_today": "Hoje",
  "header_upcoming": "à vir",
  "header_noduedate": "Sem prazo",

  "createdDate": "Criado:",

  "dayLate": "dia de atraso",
  "daysLate": "dias de atraso",

  "dayLeft": "dia restante",
  "daysLeft": " dias restantes",

  "lastUpdate": "Últimas atualizações:",
  "minutesAgo":"minuto(s) atrás",
  "hoursAgo":"hora(s) atrás",
  "daysAgo":"dia(s) atrás",

  "visitTodo": "Visite este todo",
  "assignedTo": "Atribuído a {x}",

  "countOverdues":"ToDo(s) atrasado(s)",
  "countToday":"ToDo(s) para hoje",
  "countUpcoming":"ToDo(s) à vir",
  "countNoDueDate":"ToDo(s) sem prazo",

  "needAuth1":"Clique em",
  "needAuth2":"para sincronizar a sua conta Basecamp com a extenção.",

  "thankYou":"Obrigado!",
  "syncMess":"A sua exteção ToDo-Basecamp já está conectada à sua conta! Vocè está pronto para começar a usar a sua extenção.",

  "achievement1":"Bom trabalho!",
  "achievement2":"Bem feitoe!",
  "achievement3":"Excelente!"

};